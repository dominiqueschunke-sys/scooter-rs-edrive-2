Scooter RS e-Drive Web-App v0.3

Enthält:
- RS6-inspiriertes Virtual Cockpit (Demo, keine Live-Scooter-Daten)
- Fahrtenbuch mit lokal gespeicherten Fahrten
- Optionales GPS-Tracking über iPhone-Browser nach ausdrücklicher Standortfreigabe
- CSV-Export der Fahrten
- Systemdiagnose, lokale UI-Profile, Tuning-Regler als reine Vorschau
- PWA-Dateien für HTTPS-Hosting und Home-Bildschirm

WICHTIG:
- Kein Bluetooth zum Xiaomi Scooter 5 implementiert.
- Keine echten Scooter-Befehle oder Tuningänderungen werden gesendet.
- GPS funktioniert zuverlässig nur über eine HTTPS-Webadresse und nach Zustimmung.
- GPS misst die Bewegung des iPhones, nicht die internen Scooter-Sensordaten.
- Fahrten und Profile werden lokal im Browser gespeichert. Browserdaten löschen kann sie entfernen.
- Um auf iPhone Safari als Home-Screen-Web-App zu nutzen, müssen die Dateien über HTTPS gehostet werden.
